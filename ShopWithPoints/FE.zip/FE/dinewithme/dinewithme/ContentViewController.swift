
// restaurants list in floating panel 
import UIKit

class ContentViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{

    let controller = RestaurantsController()
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var tableSource = [Restaurant]()
    @IBOutlet var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        controller.getRestaurants(latitude: latitude, longitude: longitude, comp:{
            data in
            self.tableSource = data
            //does this operation in the main thread
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        })
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    
    //define table rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section:Int) -> Int {
        return tableSource.count
    }
    
    //for each row set cell text label
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = tableSource[indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedRestaurant = tableSource[indexPath.row]
        
        print(selectedRestaurant)
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "restaurant-tap"), object: selectedRestaurant)
  }
    
}
