

import UIKit

class ReviewCell: UITableViewCell {
    
    @IBOutlet var userName: UILabel!
    @IBOutlet var userImage: UILabel!
    @IBOutlet var reviewText: UIImage!

   
    

}
