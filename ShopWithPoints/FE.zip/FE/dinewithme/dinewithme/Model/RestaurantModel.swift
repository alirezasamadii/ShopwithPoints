
import Foundation


struct PageResponse: Codable {
    let items: [Restaurant]
}

struct Restaurant: Codable {
    let _id: String
    let name: String
    let latitude: Double
    let longitude: Double
    let image: String?
}

struct Wallet: Codable {
    let _id: String?
    let userID: String?
    let points: Int?
}

struct Token: Codable {
    let token: String?
}

struct Review: Codable {
    let _id: String?
    let userID: String?
    let restaurantID: String?
    let score: Int?
    let reviewText: String?
    let userName: String?
    let createdAt: Int?
    
    
    init( userId: String, restaurantID: String, score: Int, reviewText: String, userName: String) {
        self.reviewText = reviewText
        self.userID = userId
        self.restaurantID = restaurantID
        self.score = score
        self.userName = userName
        self._id = ""
        self.createdAt = 0
    }
    

}
