
import Foundation

struct RestaurantsController {
    
    
    
    func getRestaurants(latitude: Double, longitude: Double, comp: @escaping([Restaurant]) -> ()) {
        var urlString = "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/restaurants";
        urlString += "?lat=" + String(latitude);
        urlString += "&lon=" + String(longitude);
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data, error == nil  else {
                //TODO error calling api
                return
            }
            
            //convert data to codable oject
            var result: [Restaurant]?
            do {
                result = try JSONDecoder().decode([Restaurant].self, from: data)
                comp(result ?? [])
            } catch {
                //TODO error converting response to class
            }
        }.resume() //the function resume starts the request
    }
    
    func getWallet(comp: @escaping(Wallet) -> ()) {
        let userId: String = DataHolder.userId?.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? ""
        let url = URL(string: "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/wallet/users/" + userId)
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data, error == nil  else {
                //TODO error calling api
                return
            }
            
            //convert data to codable oject
            var result: Wallet?
            do {
                result = try JSONDecoder().decode(Wallet.self, from: data)
                comp(result!)
            } catch {
                //TODO error converting response to class
            }
        }.resume() //the function resume starts the request
    }
    
    func getReviewsByRestaurant(restaurantId: String, comp: @escaping([Review]) -> ()) {
        let url = URL(string: "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/restaurants/"+restaurantId+"/reviews")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data, error == nil  else {
                //TODO error calling api
                return
            }
            //convert data to codable oject
            var result: [Review]?
            do {
                result = try JSONDecoder().decode([Review].self, from: data)
                comp(result ?? [])
            } catch {
                print(error)
            }
        }.resume() //the function resume starts the request
    }
    
    func getWalletToken(userId: String, comp: @escaping(Token?) -> ()) {
        // url encoding of user id becuz user id contains pipe
        let userId: String = DataHolder.userId?.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? ""
        // api call to aws
        let url = URL(string: "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/wallet/users/" + userId + "/token")
        URLSession.shared.dataTask(with: url!) { data, response, error in
            guard let data = data, error == nil  else {
                //TODO error calling api
                return
            }
            //convert data to codable oject
            var result: Token?
            do {
                // decode the json recived to token object
                result = try JSONDecoder().decode(Token.self, from: data)
                comp(result)
            } catch {
                print(error)
            }
        }.resume() //the function resume starts the request
    }
    
    func createReview(review: Review, comp: @escaping(String) -> ())  {
        guard let url = URL(string: "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/restaurants/"+review.restaurantID!+"/reviews") else {
            return
        }
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let stream = try JSONEncoder().encode(review)
            let json = try JSONSerialization.jsonObject(with: stream, options:[])
            
            request.httpBody = try? JSONSerialization.data(withJSONObject: json, options: .fragmentsAllowed)
            
            let task = URLSession.shared.dataTask(with: request, completionHandler: {data, response, error in
                if let data = data, let response = response as? HTTPURLResponse {
                
                    if(response.statusCode == 400) {
                        comp("You cannot post another review for this restaurant")
                    }
                    if(response.statusCode != 201 ) {
                        comp("Generic error while posting review")
                    }
                    comp("ok")
                }
            })
            task.resume()
        } catch  {
            print(error)
            //throw RestError.runtimeError("Generic error while posting review")
        }
        

    }
    
    
    func redeemPoints(token: String, points: Int, comp: @escaping(String) -> ())  {
        let escapedToken =  token.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? ""
        var urlString = "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/redeem";
        urlString += "?points=" + String(points);
        urlString += "&token=" + escapedToken;
        
        guard let url = URL(string: urlString) else {
            return
        }
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
            let task = URLSession.shared.dataTask(with: request, completionHandler: {data, response, error in
                if let data = data, let response = response as? HTTPURLResponse {
                
                    if(response.statusCode == 400) {
                        comp("QR-CODE is not valid")
                    }
                    if(response.statusCode != 204 ) {
                        comp("Generic error while redeeming points")
                    }
                    comp("ok")
                }
            })
            task.resume()
        } catch  {
            print(error)
            //throw RestError.runtimeError("Generic error while posting review")
        }
        

    }
    
}

enum RestError: Error {
    case runtimeError(String)
}


