
import UIKit
import MultilineTextField
import Lock

class ReviewViewController: UIViewController {
    
    @IBOutlet var reviewScore: UISlider!
    @IBOutlet var reviewText: UITextField!
    @IBOutlet var submitReview: UIButton!
    @IBOutlet var backButton: UIButton!
    var controller = RestaurantsController()
    
    var restaurant: Restaurant?

    override func viewDidLoad() {
        super.viewDidLoad()
        reviewText.textColor = UIColor.white
        let tapGestureBackground = UITapGestureRecognizer(target: self, action: #selector(self.backgroundTapped(_:)))
        self.view.addGestureRecognizer(tapGestureBackground)
        
        self.reviewScore.minimumValue = 1
        self.reviewScore.maximumValue = 10
        self.reviewScore.value = 1
    
        
        submitReview.addTarget(self, action: #selector(submitReview(_:)), for: .touchUpInside)
        backButton.addTarget(self, action: #selector(backButton(_:)), for: .touchUpInside)
    }
    
    @objc func backgroundTapped(_ sender: UITapGestureRecognizer)
    {
        // hide keyboard and exit from text editor
        self.reviewText.resignFirstResponder()
    }
    
    @IBAction func backButton(_ sender: AnyObject) {
        //dismiss your viewController
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submitReview(_ sender: AnyObject) {
        let text = self.reviewText.text
        let score = Int(self.reviewScore.value)
        
        if(text == nil || text?.isEmpty ?? false) {
            print("showing error dialog")
            self.presentAlert(title: "Error", message: "Type review text")
        } else {
            //create object review
            var review = Review.init(userId: DataHolder.userId!,
                                     restaurantID: restaurant?._id ?? "",
                                     score: score ?? 1,
                                     reviewText: text ?? "",
                                     userName: DataHolder.userName!)
            
            do {
             controller.createReview(review: review, comp: {response in
                                        //does this operation in the main thread
                                        DispatchQueue.main.async {
                                            if(response == "ok") {
                                                // Create new Alert
                                                var dialogMessage = UIAlertController(title: "Review", message: "Review posted with success", preferredStyle: .alert)
                                                
                                                // Create OK button with action handler
                                                let ok = UIAlertAction(title: "Go back", style: .default, handler: { (action) -> Void in
                                                    self.dismiss(animated: true, completion: nil)
                                                 })
                                                
                                                //Add OK button to a dialog message
                                                dialogMessage.addAction(ok)
                                                // Present Alert to
                                                self.present(dialogMessage, animated: true, completion: nil)
                                
                                            } else {
                                                self.presentAlert(title: "Error", message: response)
                                            }
                                        }})
            } catch RestError.runtimeError(let errorMessage) {
                self.presentAlert(title: "Error", message: errorMessage)
            }
            
        }
    }
    
    func presentAlert(title: String, message: String) {
        // Create new Alert
        var dialogMessage = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        // Create OK button with action handler
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("Ok button tapped")
         })
        
        //Add OK button to a dialog message
        dialogMessage.addAction(ok)
        // Present Alert to
        self.present(dialogMessage, animated: true, completion: nil)
    }

    

}

