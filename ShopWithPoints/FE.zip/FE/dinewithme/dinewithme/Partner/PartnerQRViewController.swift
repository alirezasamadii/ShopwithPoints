// camera opens

import UIKit

class PartnerQRViewController: UIViewController {
    
    @IBOutlet var backButton: UIButton!
    //for opening camera
    var testVC: ScannerViewController = ScannerViewController();

    override func viewDidLoad() {
        super.viewDidLoad()
        backButton.addTarget(self, action: #selector(backButton(_:)), for: .touchUpInside)
        
        self.testVC.view.frame = CGRect(x: 0, y: 0, width:350, height: 350);
        self.view.addSubview(testVC.view);
        
        var qrCodeTime = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(checkQRCODE), userInfo: nil, repeats: true)

    }
    
    @objc func checkQRCODE()
    {
        if(DataHolder.qrCode != nil) {
            print(DataHolder.qrCode)
            let vc = storyboard?.instantiateViewController(withIdentifier: "p_redeem_points") as! PartnerRedeemViewController
            
            vc.qrToken = DataHolder.qrCode
            DataHolder.qrCode = nil
            
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
        }
    }
    
    @IBAction func backButton(_ sender: AnyObject) {
        //dismiss your viewController

        self.dismiss(animated: true, completion: nil)
    }
    



}
