
import UIKit
import Auth0

class PartnerHomeViewController: UIViewController {
    
    @IBOutlet var userLabel: UILabel!
    @IBOutlet var scanButton: UIButton!
    @IBOutlet weak var logoutButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.userLabel.text? = DataHolder.userName ?? ""
        scanButton.addTarget(self, action: #selector(scanButton(_:)), for: .touchUpInside)
        self.logoutButton.addTarget(self, action: #selector(logoutButton(_:)), for: .touchUpInside)
    }
    
    @IBAction func scanButton(_ sender: AnyObject) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "partner_qr_code_scanner") as! PartnerQRViewController

        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
    
    @IBAction func logoutButton(_ sender: AnyObject) {
        //dismiss your viewController
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            // calls auth zero to perform logaout and clear session
            Auth0
              .webAuth()
              .clearSession(federated: false) { result in
                  DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                      let vc = self.storyboard?.instantiateViewController(withIdentifier: "auth_view") as! AuthViewController
                      vc.modalPresentationStyle = .fullScreen
                      self.present(vc, animated: true)
                  }
              } // clearSession()
        }
    }

}
