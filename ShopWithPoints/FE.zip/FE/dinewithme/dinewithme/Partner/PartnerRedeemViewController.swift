
import UIKit
import JWTDecode

class PartnerRedeemViewController: UIViewController {
    
    @IBOutlet var stepper: UIStepper!
    @IBOutlet var pointsLabel: UILabel!
    @IBOutlet var customerLabel: UILabel!
    @IBOutlet var walletIdLabel: UILabel!
    @IBOutlet var confirmPaymentButton: UIButton!
    var qrToken: String?
    var points: Int = 0
    var controller = RestaurantsController()
    override func viewDidLoad() {
        super.viewDidLoad()
        confirmPaymentButton.addTarget(self, action: #selector(redeemPoints(_:)), for: .touchUpInside)
        
        do {
            let jwt = try decode(jwt: qrToken ?? "")
            self.points = jwt.claim(name: "points").integer ?? 0
            let walletId = jwt.claim(name: "walletId").string ?? "Anonymous"
            
            self.pointsLabel.text? = String(self.points)
            self.walletIdLabel.text? = walletId
            
            self.stepper.minimumValue = 1
            self.stepper.maximumValue = Double(self.points)
            self.stepper.value = Double(self.points)
            self.stepper.addTarget(self, action: #selector(self.stepperValueChanged(_:)), for: UIControl.Event.valueChanged)
            
        } catch {
            print(error)
        }
    }
    
    // handle stepper value change action
    @IBAction func stepperValueChanged(_ stepper: UIStepper) {
        let stepperValue = Int(stepper.value)
        self.points = stepperValue
        
        self.pointsLabel.text? = String(self.points)

    }  
    @IBAction func redeemPoints(_ sender: AnyObject) {
      
        
        do {
            controller.redeemPoints(token: self.qrToken!, points: self.points, comp: {response in
                                    //does this operation in the main thread
                                    DispatchQueue.main.async {
                                        if(response == "ok") {
                                            // Create new Alert
                                            var dialogMessage = UIAlertController(title: "Redeem", message: "Points redeemed", preferredStyle: .alert)
                                            
                                            // Create OK button with action handler
                                            let ok = UIAlertAction(title: "Go back", style: .default, handler: { (action) -> Void in
                                                
                                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "partner_home") as! PartnerHomeViewController
                                                vc.modalPresentationStyle = .fullScreen
                                                self.present(vc, animated: true)
                                                
                                             })
                                            
                                            //Add OK button to a dialog message
                                            dialogMessage.addAction(ok)
                                            // Present Alert to
                                            self.present(dialogMessage, animated: true, completion: nil)
                            
                                        } else {
                                            var dialogMessage = UIAlertController(title: "Error", message: response, preferredStyle: .alert)
                                            
                                            // Create OK button with action handler
                                            let ok = UIAlertAction(title: "Go back", style: .default, handler: { (action) -> Void in
                                                
                                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "partner_home") as! PartnerHomeViewController
                                                vc.modalPresentationStyle = .fullScreen
                                                self.present(vc, animated: true)
                                                
                                             })
                                            
                                            //Add OK button to a dialog message
                                            dialogMessage.addAction(ok)
                                            // Present Alert to
                                            self.present(dialogMessage, animated: true, completion: nil)
                                        }
                                    }})
        } catch RestError.runtimeError(let errorMessage) {
            self.presentAlert(title: "Error", message: errorMessage)
        }  }
    func presentAlert(title: String, message: String) {
        // Create new Alert
        var dialogMessage = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        // Create OK button with action handler
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            print("Ok button tapped")
         })
        
        //Add OK button to a dialog message
        dialogMessage.addAction(ok)
        // Present Alert to
        self.present(dialogMessage, animated: true, completion: nil)  }
        
        }
