
// main view of consumer
import UIKit
import FloatingPanel
import CoreLocation
import MapKit
import Lock
import Auth0
import JWTDecode
import FontAwesome_swift

class ViewController: UIViewController, FloatingPanelControllerDelegate, CLLocationManagerDelegate, MKMapViewDelegate {
    // UI components and Logic
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var profilePicture: UIImageView!
    @IBOutlet weak var logoutButton: UIButton!
    var locationManager: CLLocationManager!
    var zoomed = false
    var token: String? = nil
    var controller = RestaurantsController()
    var latitude: Double = 0.0
    var longitude: Double = 0.0

    // func is ineherited form UIViewController and it's called
    // when the view has been loaded and ready to show content
    override func viewDidLoad() {
        super.viewDidLoad()
        // prepare map
        mapView.delegate = self
        mapView.showsUserLocation = true
        // changes the behaviour of pins on the map , to description of locations
        mapView.register(customAnnotationView.self, forAnnotationViewWithReuseIdentifier: MKMapViewDefaultAnnotationViewReuseIdentifier)
        
        prepareLocationManager()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.prepareFloatingPanel()
        }
       
        self.logoutButton.addTarget(self, action: #selector(logoutButton(_:)), for: .touchUpInside)
        //when you tap on restaurant on floating panel it goes to the restaurant detail view
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.focusOnRestaurant(_:)),
                                               name: NSNotification.Name(rawValue: "restaurant-tap"),
                                               object: nil)
        // used to have a listener after tapping on image
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(profilePictureTapped(tapGestureRecognizer:)))
        profilePicture.isUserInteractionEnabled = true
        profilePicture.addGestureRecognizer(tapGestureRecognizer)
        self.setProfilePic(imageUrl: DataHolder.userPicture!)
    
        

        // calling apis 
        controller.getRestaurants(latitude: latitude, longitude: longitude, comp:{
            // recieves restaurants in restaurant call
            restaurants in
            //does this operation in the main thread
            DispatchQueue.main.async {
                for r in restaurants {// for each restaurant add a pin on the map
                    let restaurant = Place(title: r.name, coordinate: CLLocationCoordinate2D(latitude: r.latitude, longitude: r.longitude), info: "")
                    self.mapView.addAnnotation(restaurant)
                }
            }
        })
        
    }
    
    
    //prepare location manager
    func prepareLocationManager() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        // ask for permissiion with info.plist . everytime we need permission we need to put it in info.plist
        locationManager.requestWhenInUseAuthorization() 
                // if permission is done it will start reciving user location
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
    }
    
    
    func setProfilePic(imageUrl: String) {
        let url = URL(string: imageUrl)!
        // URLSession.shared.dataTask(with: url) is called in main thread, which will iinstantiate another thread
        // to avoid performance of main thread
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("Failed fetching image:", error)
                return
            }

            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("Not a proper HTTPURLResponse or statusCode")
                return
            }

            DispatchQueue.main.async { // if it has picture , set picture 
                self.profilePicture.image = UIImage(data: data!)
            }
        }.resume()
    }

    // another view controller ( aview inside another view)
    func prepareFloatingPanel() {
        let floatingPanelController = FloatingPanelController()
        floatingPanelController.delegate = self
        
        // these are getting the view from story board
        guard let contentVC = storyboard?.instantiateViewController(withIdentifier: "fpc_content") as? ContentViewController else {return}
        contentVC.longitude = longitude
        contentVC.latitude = latitude
        
        // then put the content view controller (which are list of restaurants) in the floating panel 
        floatingPanelController.set(contentViewController: contentVC)
        floatingPanelController.addPanel(toParent: self)
        
    }
                                               
   @objc func focusOnRestaurant(_ notification: NSNotification) {
      print("focusOnRestaurant")
      // tap has info of reastaurant so we use this Notification to comunicate between contentview and the view controler 
      let r = notification.object as! Restaurant
       
       let vc = storyboard?.instantiateViewController(withIdentifier: "restaurant-detail") as! RestaurantDetailViewController
       vc.restaurant = r
       vc.modalPresentationStyle = .fullScreen
       present(vc, animated: true)
   }
    
    @objc func profilePictureTapped(tapGestureRecognizer: UITapGestureRecognizer){
        //instantiate wallet view and present it
        let vc = storyboard?.instantiateViewController(withIdentifier: "wallet-view") as! WalletViewController
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
    
    // centers to the current location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        // zoom to current location
        if(!zoomed) {
            zoomed = true
            latitude = locValue.latitude
            longitude = locValue.longitude
            mapView.centerToLocation(CLLocation(latitude: locValue.latitude, longitude: locValue.longitude))
        }
    }
    
    
    @IBAction func logoutButton(_ sender: AnyObject) {
        //calls auth0 to perform logout
        //dismiss your viewController
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            Auth0
              .webAuth()
              .clearSession(federated: false) { result in
                  DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {// this is dispatched on main app to be performed

                      // after logout go to login page
                      let vc = self.storyboard?.instantiateViewController(withIdentifier: "auth_view") as! AuthViewController
                      vc.modalPresentationStyle = .fullScreen
                      self.present(vc, animated: true)
                  }
              }
        }
    }

}

                                               

private extension MKMapView {
  func centerToLocation(
    _ location: CLLocation,
    regionRadius: CLLocationDistance = 2000
  ) {
    let coordinateRegion = MKCoordinateRegion(
      center: location.coordinate,
      latitudinalMeters: regionRadius,
      longitudinalMeters: regionRadius)
    setRegion(coordinateRegion, animated: true)
  }
}


struct DataHolder {
    static var idToken: String? = nil
    static var userId: String? = nil
    static var userName: String? = nil
    static var userPicture: String? = nil
    static var userEmail: String? = nil
    static var role: String = "consumer"
    static var qrCode: String? = nil


}
