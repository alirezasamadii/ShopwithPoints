
import UIKit

class RestaurantDetailViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet var restaurantTitle: UILabel!
    @IBOutlet var restaurantImage: UIImageView!
    @IBOutlet var backButton: UIButton!
    @IBOutlet var tableView: UITableView!
    @IBOutlet var reviewButton: UIButton!
    @IBOutlet var avarageVote: UILabel!


    var restaurant: Restaurant?
    var tableSource = [Review]()
    
    let controller = RestaurantsController()

    override func viewDidLoad() {
        super.viewDidLoad()
        restaurantTitle.text = restaurant?.name ?? "title"
        restaurantTitle.font = UIFont(name:"HelveticaNeue-Bold", size: 32.0)
        reviewButton.layer.cornerRadius = 10.0
        setRestaurantImage()
        
    
        backButton.addTarget(self, action: #selector(backButtonAction(_:)), for: .touchUpInside)
        reviewButton.addTarget(self, action: #selector(reviewButton(_:)), for: .touchUpInside)

        //additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
       
        
        controller.getReviewsByRestaurant(restaurantId: restaurant!._id,  comp: {data in
            self.tableSource = data
            var avg = 0
            if(!data.isEmpty) {
                 avg = data.map{ $0.score ?? 0}.reduce(0, +) / data.count
            }
           
        
            //does this operation in the main thread
            DispatchQueue.main.async {
                self.avarageVote.text? = String(avg)
                self.tableView.reloadData()
            }
        })
    }
    
    
    //define table rows
    func tableView(_ tableView: UITableView, numberOfRowsInSection section:Int) -> Int {
        return tableSource.count
    }
    
    //for each row set cell text label
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let review = tableSource[indexPath.row]
        var cell = tableView.dequeueReusableCell(withIdentifier: "customCell", for: indexPath) as! ReviewTableViewCell
    
        cell.score?.text = String(review.score ?? 1)
        cell.userName?.text = review.userName ?? "Anonymous"
        cell.reviewText?.text = review.reviewText ?? "Empty review"
        return cell
    }
    
    
    func setRestaurantImage() {
        let url = URL(string: restaurant?.image ?? "https://backend.squisitalia.it/img/foto/locali/11047_2.jpg")!
    
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("Failed fetching image:", error)
                return
            }

            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("Not a proper HTTPURLResponse or statusCode")
                return
            }

            DispatchQueue.main.async {
                self.restaurantImage.image = UIImage(data: data!)
            }
        }.resume()
    }
    
    
    @IBAction func backButtonAction(_ sender: AnyObject) {
        //dismiss your viewController
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func reviewButton(_ sender: AnyObject) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "review-view") as! ReviewViewController
        vc.restaurant = self.restaurant
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }

}

