
import UIKit

class ReviewTableViewCell: UITableViewCell {
    
    @IBOutlet weak var reviewText: UILabel?
    @IBOutlet weak var userName: UILabel?
    @IBOutlet weak var score: UILabel?

    

}
