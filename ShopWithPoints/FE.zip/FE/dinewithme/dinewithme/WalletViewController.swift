

import UIKit

class WalletViewController: UIViewController {
    
    @IBOutlet var qrCode:  UIImageView!
    @IBOutlet var pointsLabel: UILabel!
    @IBOutlet var backButton: UIButton!
    
    let controller = RestaurantsController()

    override func viewDidLoad() {
        super.viewDidLoad()
        backButton.addTarget(self, action: #selector(backButton(_:)), for: .touchUpInside)
        
        //self.setQrCodeImage()
        // api call 
        controller.getWalletToken(userId: DataHolder.userId!, comp: {
            // token is JWT , to make sure the user is the one who is going to redeem the points,
            // because the user is already authenticated, and every time is different
            // plus we can associate expiration to qr code to avoid stealing , 
            token in
            DispatchQueue.main.async {
                self.qrCode.image = UIImageView.init(image: QRCodeDataSet( url: token!.token!).getQRImage()).image
            }
        })
        
        controller.getWallet(comp: {data in
        
            DispatchQueue.main.async {
                self.pointsLabel.text? = String(data.points ?? 0 )
            }
        })

        // Do any additional setup after loading the view.
    }
    
    // not used anymore
    func setQrCodeImage() {
        let userId: String = DataHolder.userId?.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? ""
        let stringUrl: String = "https://o5p3dz7vj0.execute-api.eu-west-1.amazonaws.com/dev/api/wallet/users/" + userId + "/qr"
    
        let url = URL(string: stringUrl ?? "")!
    
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print("Failed fetching image:", error)
                return
            }

            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("Not a proper HTTPURLResponse or statusCode")
                return
            }

            DispatchQueue.main.async {
                self.qrCode.image = UIImage(data: data!)
            }
        }.resume()
    }
    
    @IBAction func backButton(_ sender: AnyObject) {
        //dismiss your viewController
        self.dismiss(animated: true, completion: nil)
    }

    
    


}


import SwiftUI
import Foundation
import UIKit

struct ContentView: View {
    
    
    var body: some View {
        ZStack {
            QRView().frame(width: 300, height: 300, alignment: .center)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct QRView: UIViewRepresentable {
    func updateUIView(_ uiView: UIImageView, context: Context) {
        
    }
    
   

    func makeUIView(context: Context) -> UIImageView {
        return UIImageView.init(image: QRCodeDataSet(logo: UIImage.init(named: "red-hat")!, url: "https://google.com").getQRImage())
    }

}


struct QRCodeDataSet {
    let logo: UIImage?
    let url: String
    let backgroundColor: CIColor
    let color: CIColor
    let size: CGSize
    
    init(logo: UIImage? = nil, url: String) {
        self.logo = logo
        self.url = url
        self.backgroundColor = CIColor(red: 1,green: 1,blue: 1)
        self.color = CIColor(red: 1,green: 0.46,blue: 0.46)
        self.size = CGSize(width: 300, height: 300)
    }
    //rgb(255,  , 118)
    init(logo: UIImage? = nil, url: String, backgroundColor: CIColor, color: CIColor, size: CGSize) {
        self.logo = logo
        self.url = url
        self.backgroundColor = backgroundColor
        self.color = color
        self.size = size
    }
    
    func getQRImage() -> UIImage? {
        
        guard var image  = createCIImage() else { return nil}
        
        
        ///scale to width:height
        let scaleW = self.size.width/image.extent.size.width
        let scaleH = self.size.height/image.extent.size.height
        let transform = CGAffineTransform(scaleX: scaleW, y: scaleH)
        image = image.transformed(by: transform)
        
        /// add logo
        if let logo = logo, let newImage =  addLogo(image: image, logo: logo) {
           image = newImage
        }
        
        
        /// update color
        if let colorImgae = updateColor(image: image) {
            image = colorImgae
        }
        
        return UIImage(ciImage: image)
        
    }
    
    private func updateColor(image: CIImage) -> CIImage? {
        guard let colorFilter = CIFilter(name: "CIFalseColor") else { return nil }
        
        colorFilter.setValue(image, forKey: kCIInputImageKey)
        colorFilter.setValue(color, forKey: "inputColor0")
        colorFilter.setValue(backgroundColor, forKey: "inputColor1")
        return colorFilter.outputImage
    }
    
    private func addLogo(image: CIImage, logo: UIImage) -> CIImage? {
        
        guard let combinedFilter = CIFilter(name: "CISourceOverCompositing") else { return nil }
        guard let logo = logo.cgImage else {
            return image
        }
        
        let ciLogo = CIImage(cgImage: logo)

        
        let centerTransform = CGAffineTransform(translationX: image.extent.midX - (ciLogo.extent.size.width / 2), y: image.extent.midY - (ciLogo.extent.size.height / 2))
        
        combinedFilter.setValue(ciLogo.transformed(by: centerTransform), forKey: "inputImage")
        combinedFilter.setValue(image, forKey: "inputBackgroundImage")
        return combinedFilter.outputImage
    }
    
    private func createCIImage() -> CIImage? {
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else {
            return nil
        }
        filter.setDefaults()
        filter.setValue(url.data(using: String.Encoding.ascii), forKey: "inputMessage")
        filter.setValue("H", forKey: "inputCorrectionLevel")
        //https://www.qrcode.com/en/about/error_correction.html
        return filter.outputImage
    }
}

