// 01- first view ( view with welcome)
// storyboard : where we create graphical part of the views , each view has storyboardID used to navigate
// between the views and the class, containing the logic of that view
// and also first view must be selected among all the views of the app
import UIKit
import Auth0
import JWTDecode

class AuthViewController: UIViewController {
    //IBOutlet is a link between my graphical view interface and my logic classs
    @IBOutlet weak var background: UIImageView!
    @IBOutlet var loginButton: UIButton! 

    // the first function called when the view is loaded 
    override func viewDidLoad() { 
        super.viewDidLoad()
        // when i click the button call its function : loginButton
        loginButton.addTarget(self, action: #selector(loginButton(_:)), for: .touchUpInside)
    }
    // then this is called after the viewDid is loaded and is appeared
    override func viewDidAppear(_ animated: Bool) {
        print("Auth DidApper")
        super.viewDidAppear(animated)
        
    }
    
    
    @IBAction func loginButton(_ sender: AnyObject) {
        //login button calls authentication function
        self.auth()
    }
    
    // for authentication i used service which is called Auth0
    // secure authentication
    // social-account log in
    // user managment : assiciating the roles , deleting them , etc
    // pod auth0 was also downloaded
    func auth() {
        Auth0
            .webAuth()
             //which data you will recieve after log in , here we want email , profile information, and openid (always needed)
            .scope("openid profile email") 
            // adress to auth0 account
            .audience("https://dev-3byo4b93.us.auth0.com/userinfo")
            // completion handler : a function provided , to be executed after an asyncronous call reaches its end. 
            // it means : call authentication, when it is done run completition handler :
            .start { result in
                switch result { // Auth0.Result
                // get credintials from result of authentication
                case .success(let credentials): 
                    // credentials contain JWT( json web token) this token , is used by the user to prove 
                    // his identity. it has an expiration time which after it user needs to perform login again
                    //and is made up of three parts : 1.header: is a json, containing signature alg, etc
                    // 2. payload : a json containing user information , 3. signature : proves the identity of issuer(auth0, generator of token)
                    print("Credentials: \(credentials)")
                    do {
                        // DataHolder is a static class(values are shared in all over the app)
                        DataHolder.idToken = credentials.idToken ?? nil
                        let jwt = try decode(jwt: credentials.idToken!)
                        DataHolder.userEmail = jwt.claim(name: "email").string
                        // this part is for handling if user is business or not
                        let customClaims = jwt.claim(name: "https://dinewithme.com").rawValue as!  Dictionary<String, Any>
                        DataHolder.role = customClaims["role"] as? String ?? "consumer"

                        
                        DataHolder.userName = jwt.claim(name: "name").string
                        DataHolder.userId = jwt.claim(name: "sub").string
                        DataHolder.userPicture = jwt.claim(name: "picture").string
                        
                        if(DataHolder.role == "business") {
                            // if the user is business it will istantiate another view called partner_home and present it
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "partner_home") as! PartnerHomeViewController
                            vc.modalPresentationStyle = .fullScreen
                            self.present(vc, animated: true)
                        } else {
                            // else it will instantiate main_view
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "main-view") as! ViewController
                            vc.modalPresentationStyle = .fullScreen
                            self.present(vc, animated: true)
                        }
                    } catch {}
                case .failure(let error):
                    print(error)
                }
            }
    }
    
    
}
      
    


